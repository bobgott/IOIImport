import sys
from applic.IOI_Import import main

__project__ = 'IOI_Import'
__author__ = "Robert Gottesman"
__version_date__ = "10/29/2017"

main(sys.argv[1:])
